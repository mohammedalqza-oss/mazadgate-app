package com.mzadgate.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * متصفح المزاد داخل التطبيق: العميل يتصفح كوبارت أو IAAI كزائر (بدون تسجيل دخول)،
 * والتطبيق يقرأ رقم اللوت من الصفحة المفتوحة. «زايد الآن» يرسل اللوت إلى المنصة لتنفيذ المزايدة
 * عبر حساب الوسيط المربوط، فلا يحتاج العميل أي حساب في المزاد.
 */
public class AuctionActivity extends Activity {
    static final String COPART_HOME = "https://www.copart.com/lotSearchResults?free=true";
    static final String IAAI_HOME = "https://www.iaai.com/Search";

    private static final Pattern COPART_URL = Pattern.compile("/lot/(\\d{6,10})");
    private static final Pattern IAAI_URL = Pattern.compile("(?i)(?:stockNumber=|itemid=|VehicleDetail/)(\\d{6,10})");
    // قراءة الرقم من نص الصفحة عندما لا يكون في الرابط (صفحات تُحمّل ديناميكياً)
    private static final String READ_PAGE_JS =
        "(function(){var t=(document.body&&document.body.innerText)||'';" +
        "var m=t.match(/(?:Lot|Stock)\\s*(?:#|No\\.?|Number)?\\s*:?\\s*(\\d{6,10})/i);" +
        "var h=document.querySelector('h1');" +
        "return JSON.stringify({lot:m?m[1]:'',title:h?h.innerText.trim().slice(0,80):document.title.slice(0,80)});})()";

    // العميل لا يسجّل الدخول في المزاد أبداً: نخفي أزرار الدخول والتسجيل وتنبيه "المتصفح القديم"
    private static final String CLEAN_JS =
        "(function(){if(window.__mgClean)return;window.__mgClean=1;" +
        "var W=/^(sign in|sign-in|log in|login|register|join now|sign up|create account|become a member)$/i;" +
        "var B=/(recommend using google chrome|upgrade your outdated browser|sign in to (bid|see|view))/i;" +
        "function run(){document.querySelectorAll('a,button,[role=button]').forEach(function(e){var t=(e.innerText||'').trim();" +
        "if(W.test(t)||/\\/(login|signin|registration|register)/i.test(e.getAttribute('href')||''))e.style.setProperty('display','none','important');});" +
        "document.querySelectorAll('div,p,section').forEach(function(e){if(e.children.length<6&&B.test(e.innerText||'')&&(e.innerText||'').length<260)e.style.setProperty('display','none','important');});}" +
        "run();var tm;new MutationObserver(function(){clearTimeout(tm);tm=setTimeout(run,300);}).observe(document.documentElement,{childList:true,subtree:true});})()";
    private static final java.util.regex.Pattern LOGIN_URL = java.util.regex.Pattern.compile("(?i)/(login|signin|sign-in|registration|register|join)(\\b|/|\\?|$)");

    private WebView web;
    private TextView lotText, title;
    private Button bid, bot;
    private ProgressBar bar;
    private String auction, lot = "", vehicle = "";
    private final Handler ui = new Handler(Looper.getMainLooper());

    /** يحدد المزاد من اسم الموقع، أو null إن لم يكن موقع مزاد. */
    static String auctionOf(String host) {
        if (host == null) return null;
        host = host.toLowerCase();
        if (host.equals("copart.com") || host.endsWith(".copart.com")) return "copart";
        if (host.equals("iaai.com") || host.endsWith(".iaai.com")) return "iaai";
        return null;
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_auction);
        getWindow().setStatusBarColor(Color.parseColor("#0A1630"));
        getWindow().setNavigationBarColor(Color.parseColor("#0A1630"));

        auction = getIntent().getStringExtra("auction");
        if (auction == null) auction = "copart";
        String url = getIntent().getStringExtra("url");
        if (url == null) url = "iaai".equals(auction) ? IAAI_HOME : COPART_HOME;

        web = findViewById(R.id.aweb);
        bar = findViewById(R.id.aprogress);
        lotText = findViewById(R.id.lot_text);
        title = findViewById(R.id.atitle);
        bid = findViewById(R.id.btn_bid);
        bot = findViewById(R.id.btn_bot);
        title.setText("iaai".equals(auction) ? "IAAI" : "Copart");

        findViewById(R.id.btn_close).setOnClickListener(v -> finish());
        findViewById(R.id.btn_reload).setOnClickListener(v -> web.reload());
        findViewById(R.id.btn_copart).setOnClickListener(v -> switchTo("copart"));
        findViewById(R.id.btn_iaai).setOnClickListener(v -> switchTo("iaai"));
        bid.setOnClickListener(v -> send("bid"));
        bot.setOnClickListener(v -> send("bot"));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);   // موقعا المزاد يحتاجان JavaScript للعرض
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUserAgentString(s.getUserAgentString().replace("; wv)", ")").replaceAll("Version/[\\d.]+ ", ""));
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String a = auctionOf(u.getHost());
                if (a != null && LOGIN_URL.matcher(u.getPath() == null ? "" : u.getPath()).find()) {
                    lotText.setText(getString(R.string.no_login_needed));
                    return true; // لا صفحة دخول: المزايدة تتم عبر حساب الوسيط
                }
                if (a != null) { auction = a; return false; }
                if ("https".equals(u.getScheme()) || "http".equals(u.getScheme())) return false; // صفحات مساعدة للمزاد (صور، خرائط)
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
            @Override
            public void doUpdateVisitedHistory(WebView v, String u, boolean reload) { detect(u); }
            @Override
            public void onPageFinished(WebView v, String u) { v.evaluateJavascript(CLEAN_JS, null); detect(u); }
            @Override
            public void onPageCommitVisible(WebView v, String u) { v.evaluateJavascript(CLEAN_JS, null); }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                bar.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
                bar.setProgress(p);
            }
        });

        showLot();
        web.loadUrl(url);
    }

    private void switchTo(String a) {
        auction = a;
        title.setText("iaai".equals(a) ? "IAAI" : "Copart");
        web.loadUrl("iaai".equals(a) ? IAAI_HOME : COPART_HOME);
    }

    /** يقرأ رقم اللوت من الرابط، ثم من نص الصفحة بعد اكتمال تحميلها. */
    private void detect(String url) {
        String a = auctionOf(Uri.parse(url).getHost());
        if (a != null) auction = a;
        Matcher m = ("iaai".equals(auction) ? IAAI_URL : COPART_URL).matcher(url);
        boolean onLotPage = m.find();
        if (onLotPage) { lot = m.group(1); vehicle = ""; }
        else lot = "";
        showLot();
        if (onLotPage) {
            ui.removeCallbacksAndMessages(null);
            for (int d : new int[]{900, 2500, 5000}) ui.postDelayed(this::readPage, d);
        }
    }

    private void readPage() {
        web.evaluateJavascript(READ_PAGE_JS, raw -> {
            try {
                String j = raw == null ? "" : raw.replaceAll("^\"|\"$", "").replace("\\\"", "\"").replace("\\\\", "\\");
                Matcher l = Pattern.compile("\"lot\":\"(\\d*)\"").matcher(j);
                Matcher t = Pattern.compile("\"title\":\"([^\"]*)\"").matcher(j);
                if (l.find() && !l.group(1).isEmpty() && lot.isEmpty()) lot = l.group(1);
                if (t.find()) vehicle = t.group(1).replace("\\n", " ").trim();
                showLot();
            } catch (Exception ignored) { }
        });
    }

    private void showLot() {
        boolean has = !lot.isEmpty();
        lotText.setText(has
            ? getString(R.string.lot_found, ("iaai".equals(auction) ? "IAAI" : "Copart"), lot) + (vehicle.isEmpty() ? "" : "\n" + vehicle)
            : getString(R.string.lot_hint));
        bid.setEnabled(has);
        bot.setEnabled(has);
        bid.setAlpha(has ? 1f : .45f);
        bot.setAlpha(has ? 1f : .45f);
    }

    private void send(String go) {
        if (lot.isEmpty()) return;
        Intent r = new Intent();
        r.putExtra("auction", auction);
        r.putExtra("lot", lot);
        r.putExtra("go", go);
        setResult(RESULT_OK, r);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() { ui.removeCallbacksAndMessages(null); web.destroy(); super.onDestroy(); }
}
