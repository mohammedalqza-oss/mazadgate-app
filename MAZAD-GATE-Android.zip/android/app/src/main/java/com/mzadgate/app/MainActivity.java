package com.mzadgate.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

/**
 * الشاشة الرئيسية: منصة MAZAD GATE كاملة داخل التطبيق.
 * أي رابط إلى كوبارت أو IAAI يُفتح في متصفح المزاد الداخلي (AuctionActivity) بدل المتصفح الخارجي،
 * وعند ضغط «زايد» هناك ترجع السيارة إلى المنصة مباشرة.
 */
public class MainActivity extends Activity {
    static final String HOME = "https://mzadgate.com/";
    static final int REQ_AUCTION = 41;

    private WebView web;
    private ProgressBar bar;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#0A1630"));
        w.setNavigationBarColor(Color.parseColor("#0A1630"));

        web = findViewById(R.id.web);
        bar = findViewById(R.id.progress);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(false); // روابط target=_blank تمر عبر shouldOverrideUrlLoading
        s.setUserAgentString(s.getUserAgentString() + " MazadGateApp/1.0");
        CookieManager.getInstance().setAcceptCookie(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return route(r.getUrl());
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                bar.setVisibility(View.GONE);
                findViewById(R.id.splash).setVisibility(View.GONE);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                bar.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
                bar.setProgress(p);
            }
        });

        if (state != null) web.restoreState(state);
        else web.loadUrl(startUrl(getIntent()));
    }

    /** يحدد أين يُفتح الرابط: المنصة هنا، المزادات في المتصفح الداخلي، والباقي خارج التطبيق. */
    private boolean route(Uri u) {
        String host = u.getHost() == null ? "" : u.getHost().toLowerCase();
        if (host.endsWith("mzadgate.com")) return false;
        String auction = AuctionActivity.auctionOf(host);
        if (auction != null) {
            Intent i = new Intent(this, AuctionActivity.class);
            i.putExtra("url", u.toString());
            i.putExtra("auction", auction);
            startActivityForResult(i, REQ_AUCTION);
            return true;
        }
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
        return true;
    }

    private String startUrl(Intent i) {
        Uri d = i == null ? null : i.getData();
        return d != null && d.getHost() != null && d.getHost().endsWith("mzadgate.com") ? d.toString() : HOME;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_AUCTION || res != RESULT_OK || data == null) return;
        String a = js(data.getStringExtra("auction")), lot = js(data.getStringExtra("lot")), go = js(data.getStringExtra("go"));
        // المنصة تستقبل السيارة: إن كان العميل مسجلاً تفتح نافذة المزايدة فوراً، وإلا بعد تسجيل الدخول
        String q = "/?a=" + a + "&lot=" + lot + "&go=" + go;
        web.evaluateJavascript("window.MG_openLot ? MG_openLot('" + a + "','" + lot + "','" + go + "') : location.assign('" + q + "')", null);
    }

    private static String js(String v) { return v == null ? "" : v.replaceAll("[^A-Za-z0-9-]", ""); }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

    @Override
    protected void onPause() { super.onPause(); CookieManager.getInstance().flush(); }
}
